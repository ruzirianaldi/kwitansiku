<html>
  <body onLoad="window.print();"> <!-- berfungsi agar ketika pertama dibuka, langsung memunculkan dialog print -->
   <?php
   include 'config/conn.php';
   ?>

  <style type="text/css">
    body {
    	font-size:12px;
    	font-family:Arial, Helvetica, sans-serif;

    }
    .style1{
    	font-size:12px;
    	font-family:Arial, Helvetica, sans-serif;	
    }
  </style>
  <br>
  <?php
    include ('config/conn.php');
    include ('config/fungsi.php');
    $id= $_GET['id'];
    $queri = "SELECT * from kwitansi WHERE id = $id";
    $hasil = $konek->query($queri);
    if ($hasil === false) {
      trigger_error('Perintah SQL salah! ' . $queri . 'Error: ' . $konek->error, E_USER_ERROR);
    }else{
      while ($data = $hasil->fetch_array()){ ?>
  <table width="1020px" border="10">
    <tbody>
      <tr>
        <td colspan="4" align="center"><br><H1>KWITANSI</H1></td>
      </tr>
      <tr>
        <td colspan="4"></td>
      </tr>
      <tr>
        <td colspan="4"></td>
      </tr>
      <tr>
        <td width="150px">No Kwitansi</td>
        <td colspan="4"><b><u>: <?php echo $data['no_kwi']; ?></u></b></td>
      </tr>
	 
      <tr>
        <td width="150px">Sudah Diterima Dari</td>
        <td colspan="4"><b><u>: Ketua Unit Pengelola Keuangan</u></b></td>
      </tr>
      <tr>
        <td width="150px">Uang Sejumlah</td>
        <td height="100px" style="border: 1px solid black;" width="200px" colspan="4" ><h1>Rp. <?php echo $data['nominal']?></h1></td>
      
        <!-- disini menggunakan fungsi terbilang dari file fungsi.php -->
      </tr>
      <tr>
        <td width="150px">Untuk Pembayaran</td>
        <td colspan="4"><b><u>: <?php echo $data['guna']; ?></u></b></td>
      </tr>
      
	  <tr>
        <td width="150px">Terbilang</td>
        
        <td colspan="4"><b><u>:<i><?php echo ucwords(Terbilang($data['nominal']));?> Rupiah</u></i></b></td>
      </tr>
	  <tr>
        
        <td colspan="200"align="right"><b>Dibayarkan pada tanggal : <?php echo $data['tgl_kwi']; ?></b></td>
      </tr>
	  
	  
	  
     <tr>
        <td align="center" height="100px" width="350px">Mengetahui Pimpinan,<br><br><br><br><br><br><b><?php echo $data['mengetahui'];?></b></td>
        <td align="center" width="350px">Ketua Unit Pengelola Keuangan,<br><br><br><br><br><br><b><?php echo $data['pemberi'];?></b></td>
        <td align="center" width="350px">Diterima Oleh,<br><br><br><br><br><br><b><?php echo $data['penerima'];?></b></td>
        
        <!-- disini menggunakan fungsi terbilang dari file fungsi.php -->
      </tr>

	  
	  
      <?php }}?>
    </tbody>
  </table>

</body>
</html>