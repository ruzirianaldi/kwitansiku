<?php
	$server ="srv148.niagahoster.com"; //nama server database
	$user ="u1702883_kwitansi"; //nama user database
	$passwd ="kwitansi1122"; //password database
	$dbs ="u1702883_kwitansi"; //nama database yang digunakan

	$konek=mysqli_connect($server, $user, $passwd, $dbs);
	
	// cek koneksi
	if (mysqli_connect_errno()) {
		echo "Gagal menghubungi Database: ". mysqli_connect_error();
	}
?>