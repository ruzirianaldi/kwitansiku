<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge/chrome=1">
	
	<title>Aplikasi Kwitansi Ruzi</title>
	<link rel="icon" href="KWITANSIKU.png">
	<meta property="og:title" content="kwitansiku" />
    <meta property="og:type" content="kwitansi" />
    <meta property="og:url" content="https://www.kwitansi.mtsmupulaupunjung.com/" />
    <meta property="og:image" content="https://mtsmu.pulaupunjung.com/images/image.png" />
	<link rel="stylesheet" href="_resource/dist/css/global.css" type="text/css">
	<link href="_resource/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="_resource/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="_resource/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">
    <link href="_resource/bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
</head>
<body class="backg col-md-10 col-md-offset-1">
    
	<a class="hitam" href="index.php"><h1 class="page-header" align="center"><img src="KWITANSIKU.png" style="width: 70px; height: 70px; border: 1px blue; border-radius: 15%" /><br>KWITANSIKU</h1></a>

           
            
            
            
    
	<div class="panel panel-primary">
    	<div class="panel-heading" align="right">
    	<a href="kwitansi.php"><button class="btn btn-success" ><span class="glyphicon glyphicon-plus">&nbsp Buat Kwitansi</button></a>
    	
    	</div>
    	<div class="panel-heading" >Riwayat Kwitansi yang Pernah di Buat
    	 
    	
    	</div>
        <!-- /.panel-heading -->
            <div class="panel-body">
                <div class="dataTable_wrapper responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No. Kwitansi</th>
                                <th>Penerima</th>
                                <th>Pemberi</th>
								<th>Mengetahui</th>
								<th>Kegunaan</th>
                                <th>Nominal</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                    	<tbody>
                            <?php
                                include ('config/conn.php'); //memangggil conn untuk menghubungkan ke database
                                $queri = "SELECT * from kwitansi ORDER by no_kwi"; //query untuk memilih data dari tabel database
                                $hasil = $konek->query($queri); //variabel penampung
                                if ($hasil === false) {
                                    trigger_error('Perintah SQL salah! ' . $queri . 'Error: ' . $konek->error, E_USER_ERROR);
                                    //pesan jika tidak perintah SQL salah
                                }else{
                                    //jika perintah SQL benar maka akan memanggil data sesuai pada database
                                    while ($data = $hasil->fetch_array()){
                                    	echo "<tr>
                                    		<td>".$data['no_kwi']."</td>
                                    		<td>".$data['penerima']."</td>
				                    		<td>".$data['pemberi']."</td>
											<td>".$data['mengetahui']."</td>
                                    		<td>".$data['guna']."</td>
                                    		<td>".$data['nominal']."</td>
                                    		<td>".$data['tgl_kwi']."</td>"?>
                                    		<td>
                                    			<a href="edit.php?id=<?php echo $data['id'];?>" align="center"><span class="glyphicon glyphicon-pencil" aria-hidden="true"><b> EDIT </b></span></a>&nbsp&nbsp
                                    			<br>
                                    			<a href="hapus_kwi.php?id=<?php echo $data['id'];?>" align="center"><span class="glyphicon glyphicon-remove-sign" aria-hidden="true"><b> HAPUS </b></span></a>&nbsp&nbsp
                                    			<br>
                                    			<a href="cetak_kwi.php?id=<?php echo $data['id'];?>" align="center"><span class="glyphicon glyphicon-print" aria-hidden="true"><b> CETAK </b></span></a>
                                    		</td>
                                    	</tr>
                                    <?php }
                                }?>
                        </tbody>
					</table>
                </div>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
	</body>

	<script src="_resource/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="_resource/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="_resource/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="_resource/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
    <script src="_resource/dist/js/global.js"></script>
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
    <footer align="center"> <small> this site web bukti pembayaran &copy; Copyright 2022, <a href="https://ruzirinaldi.website">ruzi rinaldi, m.kom<a></small> </footer> 
</html>